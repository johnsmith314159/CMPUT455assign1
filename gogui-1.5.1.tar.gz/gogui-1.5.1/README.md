GoGui
=====

GoGui is a graphical interface to programs that play the game of Go.

GoGui was initially developed by [Markus Enzenberger](https://github.com/enz), and hosted on [sourceforge](http://gogui.sourceforge.net/). This is an unofficial branch developed with the aim to support other games besides Go. Other games can be supported by implementing some extensions to the GTP protocol, as described in the [documentation](https://www.kayufu.com/gogui/rules.html).
